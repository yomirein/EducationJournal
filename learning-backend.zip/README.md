# Learning API

Async FastAPI backend. Copy `.env.example` to `.env`, set a cryptographically random `SECRET_KEY`, then run `docker compose up --build`. Open `/docs` for the API.

For local development use Python 3.12+, install `requirements.txt`, set `DATABASE_URL` and `SECRET_KEY`, run `alembic upgrade head`, then `uvicorn app.main:app --reload`.

The schema uses PostgreSQL JSONB-compatible JSON columns (SQLite is supported for lightweight local checks). Course/module membership is many-to-many in `course_modules`: a reusable module can belong to multiple courses. Stream participant status distinguishes pending applications from accepted students. Admin accounts must be provisioned by an administrator; public registration always creates a student.
